# LaTeX-template-phd-thesis-proposal
LaTeX Template for OIST PhD Thesis Proposal

All instructions are specified within the templates themselves. Contact Jeremie (jeremie.gillet@oist.jp) for any question related to the templates.

If you would like to make a change, PRs are welcome.
