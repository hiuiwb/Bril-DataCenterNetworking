import os

print("*****************SIMULATION BEGIN*****************")
Topology = 'Testnetconfig'
injection_rate_list = [0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95,1.00]
routing_func_list = ['min']
print('-----initializing finished-----')
progress = 0
print(f'current progress {progress}%', end="")
for routing_func in routing_func_list:
    with open('projects/Testnetconfig','r') as file:
        config = file.readlines()
    file.close()
    config[10]='routing_function = %s;\n' % routing_func
    with open('projects/Testnetconfig', 'w') as file:
        file.writelines(config)
    file.close()

    for injection_rate in injection_rate_list:
        with open('projects/Testnetconfig','r') as file:
            config = file.readlines()
        file.close()
        config[10]='routing_function = %s;\n' % routing_func
        config.pop()
        
        add_injection_rate = 'injection_rate = %s;\n' % injection_rate
        config.append(add_injection_rate)

        with open('projects/Testnetconfig', 'w') as file:
            file.writelines(config)
        file.close()
        injection_rate = int(injection_rate * 100)
        command = './booksim projects/%s >projects/results/testnet_dir/%s_%s_%s' % (Topology,Topology,routing_func,injection_rate)
        os.system(command)
        progress += 10
        print(f'\r-----current progress {progress}%-----', end="")
print("\n*****************SIMULATION FINISH****************")