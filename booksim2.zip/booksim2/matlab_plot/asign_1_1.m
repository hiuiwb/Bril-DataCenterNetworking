clc; clear;

% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% Traffic pattern Uniform
% routing algorithm dor

injection_rate = linspace(0.005,0.022,10);

packet_latency_dor = [
73.0662
76.8418
83.8149
91.8645
104.239
119.377
149.792
198.997
391.166
924.686];
flit_latency_dor = [
49.2098
49.963
53.0305
55.9655
61.6683
66.2991
79.5861
97.1164
134.511
173.478];
network_latency_dor = [
71.6361
74.6871
80.5435
87.0211
97.2317
107.245
129.338
158.855
213.962
264.37];

figure('Name','Dimension order routing','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')



% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm val

injection_rate = linspace(0.005,0.022,10);

packet_latency_val = [
126.603
163.498
275
763.36
2195.81
3140.07
5028.93
5420.19
6616.17
7429.83];
flit_latency_val = [
92.6255
112.072
176.152
452.777
608.67
595.49
615.219
639.082
620.81
624.163];
network_latency_val = [
123.984
159.68
261.325
588.338
763.164
743.479
748.846
782.895
785.49
785.592];

figure('Name','Valiant randomized algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')


% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm romm

injection_rate = linspace(0.005,0.022,10);

packet_latency_romm = [
74.2736
80.2078
88.9635
100.114
112.004
152.793
263.473
783.632
1342.57
2099.52];
flit_latency_romm = [
49.3448
51.4906
54.8927
59.8575
64.4221
83.4388
110.442
162.311
172.721
183.03];
network_latency_romm = [
72.9289
77.9392
85.2276
93.8712
103.435
134.21
179.936
245.982
258.939
273.717];

figure('Name','Randomized minimal algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_romm, Color='blue',Marker = 's');
hold on;
plot(injection_rate,flit_latency_romm, Color='red',Marker = 's');
hold on;
plot(injection_rate,network_latency_romm, Color='cyan',Marker = 's');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')

% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm min

injection_rate = linspace(0.005,0.022,10);

packet_latency_min = [
73.0579
79.4548
83.6194
103.026
120.213
146.395
228.894
614.154
1130.59
1711.64];
flit_latency_min = [
51.0248
54.4017
56.1564
67.8351
78.5965
92.7529
117.972
150.876
169.241
177.158];
network_latency_min = [
71.7891
77.1725
80.1709
95.4367
108.884
126.887
159.679
213.857
235.374
253.519];

figure('Name','Minimal adaptive routing algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')




figure("Name",'Comparison of four traffic pattern','NumberTitle','off')
t = tiledlayout('flow','TileSpacing','compact');
% subplot(2,2,1);
nexttile;
plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,packet_latency_romm, Color='blue',Marker = 's');
hold on;
plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
grid on;
lgd1 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Packet Latency');
lgd1.Layout.Tile = 4;

% subplot(2,2,2);
nexttile;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,flit_latency_romm, Color='red',Marker = 's');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
grid on;
% lgd2 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Flit Latency');
% lgd2.Layout.Tile = 4;


% subplot(2,2,3)
nexttile;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');
hold on;
plot(injection_rate,network_latency_romm, Color='cyan',Marker = 's');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');
grid on;
% lgd3 = legend('dor','val','romm','min','Location','northwest');
% legend('packet\_lat','flit\_lat','network\_lat','packet\_val','flit\_val','network\_val','packet\_romm','flit\_romm','network\_romm','packet\_min','flit\_min','network\_min','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Network Latency');
% lgd3.Layout.Tile = 4;