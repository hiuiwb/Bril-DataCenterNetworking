clc; clear;

% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% Traffic pattern Tornado
% routing algorithm dor

injection_rate = linspace(0.005,0.022,10);

packet_latency_dor = [
92.5512
98.7774
117.208
139.696
219.069
471.793
1399.5
2294.67
3685.97
4574.78];
flit_latency_dor = [
65.8955
68.3627
77.0379
87.5752
129.456
214.884
353.935
431.162
456.579
461.14];
network_latency_dor = [
90.9669
96.2007
113.057
131.427
195.073
308.206
445.489
523.546
562.134
569.106];

figure('Name','Dimension order routing','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')



% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm val

injection_rate = linspace(0.005,0.022,10);

packet_latency_val = [
126.226
156.676
285.179
747.549
2053.08
3814.45
6192.3
8041.86
7796
8569.72];
flit_latency_val = [
93.5684
108.156
180.599
442.555
640.968
686.359
701.208
692.578
729.27
714.446];
network_latency_val = [
124.342
153.348
270.562
575.838
725.558
830.045
856.751
892.967
870.164
856.703];

figure('Name','Valiant randomized algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')


% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm romm

injection_rate = linspace(0.005,0.022,10);

packet_latency_romm = [
96.4438
112.702
168.245
440.438
1325.87
3148.01
4539.88
5478.99
7106.34
8106.32];
flit_latency_romm = [
67.6557
74.673
103.616
215.058
349.825
407.701
447.395
446.799
459.937
460.133];
network_latency_romm = [
94.857
109.95
159.831
272.12
443.626
522.839
551.965
546.734
552.425
579.571];

figure('Name','Randomized minimal algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_romm, Color='blue',Marker = 's');
hold on;
plot(injection_rate,flit_latency_romm, Color='red',Marker = 's');
hold on;
plot(injection_rate,network_latency_romm, Color='cyan',Marker = 's');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')

% Mesh Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% routing algorithm min

injection_rate = linspace(0.005,0.022,10);

packet_latency_min = [
92.4276
101.992
124.28
157.429
278.497
775.582
1888.02
3220.62
4601.75
6315.09];
flit_latency_min = [
69.6105
74.1709
88.0493
107.914
175.002
301.309
375.548
430.401
457.444
428.54];
network_latency_min = [
91.0017
99.497
118.963
148.367
234.037
349.928
477.1
536.745
606.393
602.46];

figure('Name','Minimal adaptive routing algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Mesh Topology')




figure("Name",'Comparison of four traffic pattern','NumberTitle','off')
t = tiledlayout('flow','TileSpacing','compact');
% subplot(2,2,1);
nexttile;
plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,packet_latency_romm, Color='blue',Marker = 's');
hold on;
plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
grid on;
lgd1 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Packet Latency');
lgd1.Layout.Tile = 4;

% subplot(2,2,2);
nexttile;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,flit_latency_romm, Color='red',Marker = 's');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
grid on;
% lgd2 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Flit Latency');
% lgd2.Layout.Tile = 4;


% subplot(2,2,3)
nexttile;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');
hold on;
plot(injection_rate,network_latency_romm, Color='cyan',Marker = 's');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');
grid on;
% lgd3 = legend('dor','val','romm','min','Location','northwest');
% legend('packet\_lat','flit\_lat','network\_lat','packet\_val','flit\_val','network\_val','packet\_romm','flit\_romm','network\_romm','packet\_min','flit\_min','network\_min','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Network Latency');
% lgd3.Layout.Tile = 4;