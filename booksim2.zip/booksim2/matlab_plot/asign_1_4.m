clc; clear;

% Torus Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% Traffic pattern Tornado
% routing algorithm dor

injection_rate = linspace(0.005,0.022,10);
injection_rate_3 = [0.005,0.0069,0.0088];

packet_latency_dor = [
92.1058
108.389
137.161
172.671
362.042
838.898
1912.07
2862.45
3938.27
5043.89];
flit_latency_dor = [
61.9455
68.7191
81.5888
99.4385
189.382
270.791
324.703
324.832
344.349
352.914];
network_latency_dor = [
90.276
104.833
128.17
157.295
277.472
361.144
403.002
408.578
411.311
422.361];

figure('Name','Dimension order routing','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')


% routing algorithm val

injection_rate = linspace(0.005,0.022,10);

packet_latency_val = [
106.959
115.671
132
152.575
197.001
289.791
519.209
1223.42
1981.35
2905.55];
flit_latency_val = [
78.292
81.4504
88.8903
98.1318
120.275
159.346
220.084
259.418
268.811
275.155];
network_latency_val = [
104.855
112.929
127.453
143.34
177.248
236.069
305.833
347.443
361.04
371.079];

figure('Name','Valiant randomized algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')

% routing algorithm min

injection_rate = linspace(0.005,0.022,10);

packet_latency_min = [
100.019
315.48
5571.58
];
flit_latency_min = [
74.2563
128.807
229.849
];
network_latency_min = [
97.5045
163.529
408.495
];

figure('Name','Minimal adaptive routing algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate_3,packet_latency_min, Color='blue',Marker = 'o');
hold on;
plot(injection_rate_3,flit_latency_min, Color='red',Marker = 'o');
hold on;
plot(injection_rate_3,network_latency_min, Color='cyan',Marker = 'o');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')




figure("Name",'Comparison of three traffic pattern','NumberTitle','off')
t = tiledlayout('flow','TileSpacing','compact');
% subplot(2,2,1);
nexttile;
plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate_3,packet_latency_min, Color='blue',Marker = 'o');
grid on;
lgd1 = legend('dor','val','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Packet Latency');
lgd1.Layout.Tile = 4;

% subplot(2,2,2);
nexttile;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate_3,flit_latency_min, Color='red',Marker = 'o');
grid on;
% lgd2 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Flit Latency');
% lgd2.Layout.Tile = 4;


% subplot(2,2,3)
nexttile;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');
hold on;
plot(injection_rate_3,network_latency_min, Color='cyan',Marker = 'o');
grid on;
% lgd3 = legend('dor','val','romm','min','Location','northwest');
% legend('packet\_lat','flit\_lat','network\_lat','packet\_val','flit\_val','network\_val','packet\_romm','flit\_romm','network\_romm','packet\_min','flit\_min','network\_min','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Network Latency');
% lgd3.Layout.Tile = 4;