% Comparison of the two topologies in terms of packet latency
% Under tornado traffic pattern
injection_rate = linspace(0.005,0.022,10);
injection_rate_3 = [0.005,0.0069,0.0088];

mesh_dor = [
92.5512
98.7774
117.208
139.696
219.069
471.793
1399.5
2294.67
3685.97
4574.78];
mesh_val = [
126.226
156.676
285.179
747.549
2053.08
3814.45
6192.3
8041.86
7796
8569.72];
mesh_romm = [
96.4438
112.702
168.245
440.438
1325.87
3148.01
4539.88
5478.99
7106.34
8106.32];
mesh_min = [
92.4276
101.992
124.28
157.429
278.497
775.582
1888.02
3220.62
4601.75
6315.09];


torus_dor = [
92.1058
108.389
137.161
172.671
362.042
838.898
1912.07
2862.45
3938.27
5043.89];
torus_val = [
106.959
115.671
132
152.575
197.001
289.791
519.209
1223.42
1981.35
2905.55];
torus_min = [
100.019
315.48
5571.58];

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,torus_dor, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Dimension Order Routing')

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_val, Color='blue',Marker = '+');
hold on;
plot(injection_rate,torus_val, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Valiant Randomized Algorithm')

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_min, Color='blue',Marker = '+');
hold on;
plot(injection_rate_3,torus_min, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Minimal Adaptive Routing')