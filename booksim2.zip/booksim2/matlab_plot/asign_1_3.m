clc; clear;

% Torus Topology
% No flow control
% injection rate from 0.005 to 0.022
% latency threshold 20000
% packet size 20
% Traffic pattern Uniform
% routing algorithm dor

injection_rate = linspace(0.005,0.022,10);

packet_latency_dor = [
66.7399
69.5791
74.6169
76.7209
83.0781
88.2678
95.1119
105.513
118.494
139.122];
flit_latency_dor = [
42.5716
43.3476
45.1903
46.1854
47.8748
49.4006
51.6748
54.2422
58.2716
62.9165];
network_latency_dor = [
65.0149
67.1535
70.6552
72.1913
76.5032
79.2485
83.882
89.2365
96.4839
104.441];

figure('Name','Dimension order routing','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')


% routing algorithm val

injection_rate = linspace(0.005,0.022,10);

packet_latency_val = [
107.974
120.072
135.254
157.945
195.304
272.25
658.898
1301.86
2276.21
3064.75];
flit_latency_val = [
78.5071
84.0434
91.0194
102.686
121.86
155.958
245.099
274.249
277.312
279.278];
network_latency_val = [
106.021
116.528
130.466
149.038
179.965
226.084
332.127
366.269
365.761
362.109];

figure('Name','Valiant randomized algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')

% routing algorithm min

injection_rate = linspace(0.005,0.022,10);

packet_latency_min = [
67.0736
69.3613
75.7793
82.82
91.8262
108.177
144.896
291.051
803.945
1535.8];
flit_latency_min = [
43.9873
45.1162
48.9873
52.1749
56.353
63.1311
71.3917
87.2741
99.242
103.491];
network_latency_min = [
65.2945
67.0838
71.8472
76.9492
82.0425
90.2746
100.749
120.425
135.229
141.041];

figure('Name','Minimal adaptive routing algorithm','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');

legend('packet\_lat','flit\_lat','network\_lat','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
%subplot(2,1,2);

% subtitle('flit average latency vs. offered load');
% xlabel('injection rate (packet length: 20 flits)');
% ylabel('flit latency');
grid on;
title('Torus Topology')




figure("Name",'Comparison of three traffic pattern','NumberTitle','off')
t = tiledlayout('flow','TileSpacing','compact');
% subplot(2,2,1);
nexttile;
plot(injection_rate,packet_latency_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,packet_latency_val, Color='blue',Marker = '^');
hold on;
plot(injection_rate,packet_latency_min, Color='blue',Marker = 'o');
grid on;
lgd1 = legend('dor','val','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Packet Latency');
lgd1.Layout.Tile = 4;

% subplot(2,2,2);
nexttile;
plot(injection_rate,flit_latency_dor, Color='red',Marker = '+');
hold on;
plot(injection_rate,flit_latency_val, Color='red',Marker = '^');
hold on;
plot(injection_rate,flit_latency_min, Color='red',Marker = 'o');
grid on;
% lgd2 = legend('dor','val','romm','min','Location','northwest');
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Flit Latency');
% lgd2.Layout.Tile = 4;


% subplot(2,2,3)
nexttile;
plot(injection_rate,network_latency_dor, Color='cyan',Marker = '+');
hold on;
plot(injection_rate,network_latency_val, Color='cyan',Marker = '^');
hold on;
plot(injection_rate,network_latency_min, Color='cyan',Marker = 'o');
grid on;
% lgd3 = legend('dor','val','romm','min','Location','northwest');
% legend('packet\_lat','flit\_lat','network\_lat','packet\_val','flit\_val','network\_val','packet\_romm','flit\_romm','network\_romm','packet\_min','flit\_min','network\_min','Location','northwest')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
title('Network Latency');
% lgd3.Layout.Tile = 4;