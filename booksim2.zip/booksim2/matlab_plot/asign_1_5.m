% mesh topology with uniform traffic and flowcontrol of (vc:4,bf:20)
injection_rate = linspace(0.005,0.022,10);
injection_rate5 = linspace(0.005,0.0126,5);
injection_rate9 = linspace(0.005,0.0201,9);


mesh_dor = [
70.976
76.8099
80.3712
87.1603
97.3517
109.592
127.506
165.402
304.805
1006.15];
mesh_val= [
127.754
155.127
249.517
1642.6
4275.11];
mesh_romm = [
72.4624
79.232
83.2038
95.5831
112.182
154.486
994.973
3016.01
6296.15];
mesh_min = [
71.158
78.0626
83.0506
93.1438
111.268
132.44
194.157
281.173
641.147
1467.9];



figure('Name','Mesh with uniform traffic','NumberTitle','off');

plot(injection_rate,mesh_dor, Color='blue',Marker = '*');
hold on;
plot(injection_rate5,mesh_val, Color='green',Marker = '*');
hold on;
plot(injection_rate9,mesh_romm, Color='red',Marker = '*');
hold on;
plot(injection_rate,mesh_min, Color='cyan',Marker = '*');
hold on;
legend('dor','val','romm','min');
subtitle('virtual channel: 4, buffer size per channel: 20');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Mesh with uniform traffic')