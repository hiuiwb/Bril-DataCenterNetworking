% 4 routers with 3 endpoints per router
injection_rate = linspace(0.50,1.00,10);


mesh_min_p1 = [
9.00424
9.55989
11.4555
15.3622
36.1957
50.0457
87.4587
114.525
165.763
209.438];
mesh_min_p1_fc6= [
8.89958
9.46639
10.9079
14.5966
33.1129
48.5042
85.7041
129.583
160.373
210.397];
mesh_min_p5 = [
1035.9
1178.85
1303.66
1452.35
1569.47
1714.97
1842.04
1966.17
2091.34
2221.98];
mesh_min_p5_fc6 = [
1037.71
1178.58
1303.54
1452.23
1571.02
1714.49
1844.23
1968.37
2093.63
2224.28];



figure('Name','Performance of Testnet with different settings','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_min_p1, Color='blue',Marker = '+');
hold on;
plot(injection_rate,mesh_min_p1_fc6, Color='blue',Marker = '*');
hold on;
legend('p1,fc3','p1,fc6');
subtitle('p: packet size; fc: flow control');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Testnet with uniform traffic and MIN routing function')

figure('Name','Performance of Testnet with different settings','NumberTitle','off');
%subplot(2,1,1);
plot(injection_rate,mesh_min_p5, Color='red',Marker = '+');
hold on;
plot(injection_rate,mesh_min_p5_fc6, Color='red',Marker = '*');
hold on;
legend('p5,fc3','p5,fc6');
subtitle('p: packet size; fc: flow control');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Testnet with uniform traffic and MIN routing function')