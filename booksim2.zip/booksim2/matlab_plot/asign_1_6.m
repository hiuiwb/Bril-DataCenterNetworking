% mesh topology with uniform traffic and flowcontrol of (vc:8,bf:20)
injection_rate = linspace(0.005,0.022,10);
injection_rate6 = linspace(0.005,0.0144,6);
injection_rate8 = linspace(0.005,0.0182,8);


mesh_dor = [
71.1348
76.9622
80.4911
87.7844
98.2077
112.963
135.599
169.159
247.456
542.698];
mesh_val= [
128.261
155.178
238.409
738.991
3624.72
4687.82];
mesh_romm = [
72.8313
80.3477
84.3721
95.5874
112.338
135.455
203.494
874.43];
mesh_min = [
71.5045
78.1588
82.9398
92.3613
106.342
138.05
188.865
270.352
391.475
766.477];



figure('Name','Mesh with uniform traffic','NumberTitle','off');

plot(injection_rate,mesh_dor, Color='blue',Marker = '*');
hold on;
plot(injection_rate6,mesh_val, Color='green',Marker = '*');
hold on;
plot(injection_rate8,mesh_romm, Color='red',Marker = '*');
hold on;
plot(injection_rate,mesh_min, Color='cyan',Marker = '*');
hold on;
legend('dor','val','romm','min');
subtitle('virtual channel: 4, buffer size per channel: 20');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Mesh with uniform traffic')