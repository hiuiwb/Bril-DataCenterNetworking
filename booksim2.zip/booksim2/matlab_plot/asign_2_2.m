% 8 routers with 4 endpoints per router
injection_rate = linspace(0.50,1.00,10);


mesh_min_p1 = [
9.34287
10.0335
11.4095
14.6115
23.1209
45.322
84.0369
119.761
158.2
192.858];
mesh_min_p1_fc6= [
9.27776
9.91647
11.266
14.5709
22.3257
48.0027
89.5332
117.538
154.02
196.502];
mesh_min_p5 = [
1048.03
1181.38
1310.65
1444.5
1574.2
1707.99
1839.84
1965.54
2088.24
2218.58];
mesh_min_p5_fc6 = [
1048.27
1180.26
1309.58
1442.91
1576.07
1707.35
1840.15
1966.2
2088.38
2218.73];



figure('Name','Performance of Testnet with different settings','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_min_p1, Color='blue',Marker = '+');
hold on;
plot(injection_rate,mesh_min_p1_fc6, Color='blue',Marker = '*');
hold on;
legend('p1,fc3','p1,fc6');
subtitle('p: packet size; fc: flow control');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Testnet with uniform traffic and MIN routing function')

figure('Name','Performance of Testnet with different settings','NumberTitle','off');
%subplot(2,1,1);
plot(injection_rate,mesh_min_p5, Color='red',Marker = '+');
hold on;
plot(injection_rate,mesh_min_p5_fc6, Color='red',Marker = '*');
hold on;
legend('p5,fc3','p5,fc6');
subtitle('p: packet size; fc: flow control');
xlabel('injection rate (packet length: 1 flit)');
ylabel('packet latency');
grid on;
title('Testnet with uniform traffic and MIN routing function')