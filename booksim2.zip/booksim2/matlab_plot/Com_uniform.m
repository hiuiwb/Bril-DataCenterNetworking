% Comparison of the two topologies in terms of packet latency
% Under uniform traffic pattern
injection_rate = linspace(0.005,0.022,10);

mesh_dor = [
73.0662
76.8418
83.8149
91.8645
104.239
119.377
149.792
198.997
391.166
924.686];
mesh_val = [
126.603
163.498
275
763.36
2195.81
3140.07
5028.93
5420.19
6616.17
7429.83];
mesh_romm = [
74.2736
80.2078
88.9635
100.114
112.004
152.793
263.473
783.632
1342.57
2099.52];
mesh_min = [
73.0579
79.4548
83.6194
103.026
120.213
146.395
228.894
614.154
1130.59
1711.64];


torus_dor = [
66.7399
69.5791
74.6169
76.7209
83.0781
88.2678
95.1119
105.513
118.494
139.122];
torus_val = [
107.974
120.072
135.254
157.945
195.304
272.25
658.898
1301.86
2276.21
3064.75];
torus_min = [
67.0736
69.3613
75.7793
82.82
91.8262
108.177
144.896
291.051
803.945
1535.8];

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_dor, Color='blue',Marker = '+');
hold on;
plot(injection_rate,torus_dor, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Dimension Order Routing')

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_val, Color='blue',Marker = '+');
hold on;
plot(injection_rate,torus_val, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Valiant Randomized Algorithm')

figure('Name','Performance Comparison of Mesh and Torus','NumberTitle','off');
%subplot(2,1,1);

plot(injection_rate,mesh_min, Color='blue',Marker = '+');
hold on;
plot(injection_rate,torus_min, Color='red',Marker = '+');
hold on;

legend('mesh','torus')
subtitle('packet average latency vs. offered load');
xlabel('injection rate (packet length: 20 flits)');
ylabel('packet latency');
grid on;
title('Minimal Adaptive Routing')